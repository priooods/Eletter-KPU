<?php

return [
    'name' => 'Letter',
];
