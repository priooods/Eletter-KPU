<?php return array (
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
  ),
  'Modules\\Letter\\Providers\\EventServiceProvider' => 
  array (
  ),
  'Modules\\Master\\Providers\\EventServiceProvider' => 
  array (
  ),
  'Modules\\User\\Providers\\EventServiceProvider' => 
  array (
  ),
);