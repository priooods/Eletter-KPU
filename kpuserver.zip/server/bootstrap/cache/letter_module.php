<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Letter\\Providers\\LetterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Letter\\Providers\\LetterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);