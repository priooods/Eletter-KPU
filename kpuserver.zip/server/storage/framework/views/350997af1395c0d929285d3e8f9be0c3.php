<?php $__env->startSection('content'); ?>
    <h1>Hello World</h1>

    <p>Module: <?php echo config('user.name'); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS TUF GAMING 15\Desktop\Angeline\kpu\server\Modules\User\resources\views\index.blade.php ENDPATH**/ ?>